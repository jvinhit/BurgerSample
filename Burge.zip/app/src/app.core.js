(function() {
    angular.module("app", ["ui.router"]);
})();
