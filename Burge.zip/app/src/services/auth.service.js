(function() {
    angular.module("app").factory("authService", authService);
    function authService() {}
})();
